#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_converter.py
=================

Тесты для mjo_converter.

Проверяет:
    1. Чтение/запись .mjo без потерь (roundtrip) на примере.
    2. Декодирование -> reencode совпадает побайтно.
    3. Корректную работу инструкции switch (case) и других сложных опкодов.
    4. Корректность XOR-шифрования.
"""

import os
import struct
import sys
import tempfile

# Импортируем конвертер
sys.path.insert(0, os.path.dirname(__file__))
from mjo_converter import (
    SIGNATURE_DECRYPTED, SIGNATURE_ENCRYPTED,
    Instruction, MjoFile, MjoFunction,
    OPCODE_TABLE, _encode_operands, _parse_operands,
    assemble_bytecode, build_mjo_from_text, disassemble,
    mjo_to_text, read_mjo, write_mjo, xor_crypt,
)


def assert_eq(a, b, msg=""):
    if a != b:
        raise AssertionError(f"{msg}\n  Expected: {a!r}\n  Got:      {b!r}")


# ----------------------------------------------------------------------------
# Тест 1: XOR-ключ — первые 4 байта должны быть 0x00 (т.к. Table32[0] = 0)
# ----------------------------------------------------------------------------

def test_xor_key():
    from mjo_converter import XOR_KEY
    assert_eq(XOR_KEY[:4], b"\x00\x00\x00\x00", "Первые 4 байта XOR-ключа")
    assert_eq(len(XOR_KEY), 1024, "Длина XOR-ключа")
    # Проверяем, что шифрование/дешифрование обратимо
    data = bytearray(b"Hello, World! This is a test of Majiro XOR cipher." * 10)
    enc = bytearray(data)
    xor_crypt(enc)
    assert enc != data, "XOR должен изменить данные"
    xor_crypt(enc)
    assert_eq(enc, data, "XOR не обратим!")
    print("[OK] test_xor_key")


# ----------------------------------------------------------------------------
# Тест 2: Roundtrip на примере
# ----------------------------------------------------------------------------

def test_roundtrip_example():
    src = "/workspace/user_input_files/sta001b0_1st_noon1.mjo"
    if not os.path.exists(src):
        print("[SKIP] test_roundtrip_example: нет примера")
        return
    with open(src, "rb") as f:
        original = f.read()
    mjo = read_mjo(src)
    text = mjo_to_text(mjo)
    new_mjo = build_mjo_from_text(text)
    with tempfile.NamedTemporaryFile(suffix=".mjo", delete=False) as f:
        tmp_path = f.name
    try:
        write_mjo(tmp_path, new_mjo)
        with open(tmp_path, "rb") as f:
            roundtrip = f.read()
        assert_eq(original, roundtrip, "Roundtrip должен быть побайтно идентичным")
        print(f"[OK] test_roundtrip_example ({len(original)} байт совпадают)")
    finally:
        os.unlink(tmp_path)


# ----------------------------------------------------------------------------
# Тест 3: Кодирование/декодирование switch (case)
# ----------------------------------------------------------------------------

def test_switch_encoding():
    # case instruction is 0x850, operand is uint16 N + int32[N] relative offsets
    opcode = 0x850
    info = OPCODE_TABLE[opcode]
    assert_eq(info.name, "switch", "Имя опкода switch")

    # Targets: 100, 200, 300 (абсолютные смещения)
    targets = [100, 200, 300]
    operands = [("case", targets)]

    # Кодируем при current_offset = 0
    encoded = _encode_operands(opcode, operands, current_offset=0)
    # 2 (uint16 N=3) + 3*4 (int32) = 14 байт
    assert_eq(len(encoded), 14, "Длина case")

    # rel = target - (current_offset + 2 + 2 + 4*N) = target - (0 + 2 + 2 + 12) = target - 16
    # 100 - 16 = 84
    # 200 - 16 = 184
    # 300 - 16 = 284
    expected = struct.pack("<H", 3) + struct.pack("<iii", 84, 184, 284)
    assert_eq(encoded, expected, "Кодирование switch")

    # Декодируем
    n, = struct.unpack("<H", encoded[:2])
    assert_eq(n, 3, "Число case'ов")
    print("[OK] test_switch_encoding")


# ----------------------------------------------------------------------------
# Тест 4: Кодирование/декодирование br (jump)
# ----------------------------------------------------------------------------

def test_br_encoding():
    opcode = 0x82C  # br
    # target = 100, current_offset = 50
    # rel = target - (current_offset + 6) = 100 - 56 = 44
    encoded = _encode_operands(opcode, [100], current_offset=50)
    expected = struct.pack("<i", 44)
    assert_eq(encoded, expected, "Кодирование br при offset=50")

    # При current_offset = 0
    encoded = _encode_operands(opcode, [6], current_offset=0)
    expected = struct.pack("<i", 0)
    assert_eq(encoded, expected, "Кодирование br при offset=0, target=6")

    # При target = next instruction
    encoded = _encode_operands(opcode, [100 + 6], current_offset=100)
    expected = struct.pack("<i", 0)
    assert_eq(encoded, expected, "Кодирование br когда target=pos_after_rel")
    print("[OK] test_br_encoding")


# ----------------------------------------------------------------------------
# Тест 5: Шифрование/дешифрование всего файла
# ----------------------------------------------------------------------------

def test_full_encryption_cycle():
    src = "/workspace/user_input_files/sta001b0_1st_noon1.mjo"
    if not os.path.exists(src):
        print("[SKIP] test_full_encryption_cycle: нет примера")
        return
    mjo = read_mjo(src)
    # Байткод в mjo.bytecode уже расшифрован
    decrypted = bytearray(mjo.bytecode)
    encrypted = bytearray(mjo.bytecode)
    xor_crypt(encrypted)
    # После шифрования должен получиться исходный байткод в файле
    with open(src, "rb") as f:
        data = f.read()
    file_bc = data[40:40 + mjo.bytecode_size]
    assert_eq(bytes(encrypted), file_bc, "Зашифрованный байткод должен совпадать с файлом")
    print(f"[OK] test_full_encryption_cycle (bytecode {len(file_bc)} байт)")


# ----------------------------------------------------------------------------
# Тест 6: Создаём минимальный .mjo вручную и проверяем roundtrip
# ----------------------------------------------------------------------------

def test_minimal_mjo():
    # Создаём минимальный .mjo с одной функцией
    mjo = MjoFile(
        signature=SIGNATURE_ENCRYPTED,
        main_offset=0,
        line_count=0,
        functions=[MjoFunction(hash=0xDEADBEEF, offset=0)],
        bytecode_size=0,  # пересчитаем
        bytecode=bytearray(),
        encrypted=True,
    )
    # Несколько инструкций:
    # ldc.i 42 (push int)
    # ldstr "hello"
    # ret
    instructions = [
        Instruction(offset=0, opcode=0x800, mnemonic="ldc.i", operands=[42],
                    raw_bytes=b""),
        Instruction(offset=4+2, opcode=0x801, mnemonic="ldstr",
                    operands=["hello"], raw_bytes=b""),
        Instruction(offset=4+2+2+7, opcode=0x82B, mnemonic="ret",
                    operands=[], raw_bytes=b""),
    ]
    bytecode = assemble_bytecode(instructions)
    mjo.bytecode = bytearray(bytecode)
    mjo.bytecode_size = len(bytecode)

    with tempfile.NamedTemporaryFile(suffix=".mjo", delete=False) as f:
        tmp = f.name
    try:
        write_mjo(tmp, mjo)
        with open(tmp, "rb") as f:
            raw = f.read()

        # Проверяем сигнатуру
        assert raw.startswith(SIGNATURE_ENCRYPTED), "Сигнатура должна быть X (зашифровано)"

        # Roundtrip
        mjo2 = read_mjo(tmp)
        text = mjo_to_text(mjo2)
        mjo3 = build_mjo_from_text(text)
        with tempfile.NamedTemporaryFile(suffix=".mjo", delete=False) as f:
            tmp2 = f.name
        try:
            write_mjo(tmp2, mjo3)
            with open(tmp2, "rb") as f:
                raw2 = f.read()
            assert_eq(raw, raw2, "Roundtrip минимального .mjo")
        finally:
            os.unlink(tmp2)
        print(f"[OK] test_minimal_mjo ({len(raw)} байт, {mjo.bytecode_size} байткода)")
    finally:
        os.unlink(tmp)


# ----------------------------------------------------------------------------
# Тест 7: Force plain (без шифрования)
# ----------------------------------------------------------------------------

def test_force_plain():
    src = "/workspace/user_input_files/sta001b0_1st_noon1.mjo"
    if not os.path.exists(src):
        print("[SKIP] test_force_plain: нет примера")
        return
    mjo = read_mjo(src)
    text = mjo_to_text(mjo)
    new_mjo = build_mjo_from_text(text)
    new_mjo.signature = SIGNATURE_DECRYPTED
    with tempfile.NamedTemporaryFile(suffix=".mjo", delete=False) as f:
        tmp = f.name
    try:
        write_mjo(tmp, new_mjo)
        with open(tmp, "rb") as f:
            data = f.read()
        assert data.startswith(SIGNATURE_DECRYPTED), "Сигнатура должна быть V"
        # Байткод должен совпадать с decrypted байткодом mjo
        # (без шифрования)
        bc_offset = 16 + 12 + 8 * len(mjo.functions) + 4
        file_bc = data[bc_offset:bc_offset + mjo.bytecode_size]
        assert_eq(file_bc, bytes(mjo.bytecode), "Байткод без шифрования")
        print(f"[OK] test_force_plain")
    finally:
        os.unlink(tmp)


# ----------------------------------------------------------------------------
# Тест 8: Модификация текста и обратная сборка
# ----------------------------------------------------------------------------

def test_text_modification():
    """Проверяем, что можно изменить текст в .txt и собрать обратно .mjo."""
    src = "/workspace/user_input_files/sta001b0_1st_noon1.mjo"
    if not os.path.exists(src):
        print("[SKIP] test_text_modification: нет примера")
        return
    mjo = read_mjo(src)
    text = mjo_to_text(mjo)
    # Считаем вхождения Driver до замены
    driver_count = text.count("Driver")
    assert driver_count > 0, "В исходном файле должно быть хотя бы одно вхождение 'Driver'"
    # Заменяем ВСЕ "Driver" на "Test" и убеждаемся, что Driver больше нет
    new_text = text.replace("Driver", "Test")
    assert "Driver" not in new_text, "После замены 'Driver' должен исчезнуть"
    new_mjo = build_mjo_from_text(new_text)

    with tempfile.NamedTemporaryFile(suffix=".mjo", delete=False) as f:
        tmp = f.name
    try:
        write_mjo(tmp, new_mjo)
        with open(tmp, "rb") as f:
            raw = f.read()
        # Байткод не должен совпадать с оригиналом (мы изменили текст)
        with open(src, "rb") as f:
            orig = f.read()
        assert raw != orig, "После изменения текста файл должен отличаться"
        # Но файл должен корректно парситься
        mjo2 = read_mjo(tmp)
        text2 = mjo_to_text(mjo2)
        assert "Driver" not in text2, "Изменённый текст не должен содержать 'Driver'"
        # Test должен встречаться столько же раз, сколько Driver раньше
        assert text2.count("Test") == driver_count, \
            f"Test должен встречаться {driver_count} раз"
        print(f"[OK] test_text_modification (заменено {driver_count} вхождений)")
    finally:
        os.unlink(tmp)


def main():
    tests = [
        test_xor_key,
        test_roundtrip_example,
        test_switch_encoding,
        test_br_encoding,
        test_full_encryption_cycle,
        test_minimal_mjo,
        test_force_plain,
        test_text_modification,
    ]
    failed = 0
    for t in tests:
        try:
            t()
        except Exception as e:
            print(f"[FAIL] {t.__name__}: {e}")
            failed += 1
    if failed:
        print(f"\n{failed} тест(ов) упало")
        return 1
    print(f"\nВсе {len(tests)} тестов прошли успешно!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
